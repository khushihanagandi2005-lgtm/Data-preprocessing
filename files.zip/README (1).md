# E-Commerce Sales: Data Cleaning, EDA & Dashboard

A data analytics project demonstrating end-to-end data preprocessing, exploratory data analysis, and dashboard-style visual reporting on a raw e-commerce sales dataset.

## Project Overview

Raw, real-world data is rarely analysis-ready. This project takes a messy e-commerce sales dataset — complete with missing values, duplicates, outliers, and inconsistent formatting — and walks through the full process of cleaning it, exploring it, and presenting key findings visually.

**Objectives**
- Handle missing values, outliers, and duplicates using documented, justified rules
- Explore the data with Pandas, Matplotlib, and Seaborn
- Build a dashboard-style visual report of key business insights

## Dataset

`raw_ecommerce_sales.csv` — 2,565 synthetic e-commerce orders (Jan 2023–Dec 2024) with the following fields:

| Column | Description |
|---|---|
| OrderID | Unique order identifier |
| OrderDate | Date of order (mixed formats in raw data) |
| Category | Product category |
| ProductPrice | Price per unit (₹) |
| Quantity | Units ordered |
| DiscountPercent | Discount applied (%) |
| CustomerCity | Customer's city |
| CustomerAge | Customer's age |
| CustomerGender | Customer's gender |
| PaymentMode | Payment method used |
| Rating | Customer rating (1–5) |
| DeliveryDays | Days taken for delivery |

The raw data was deliberately generated with realistic data quality issues (~9% of cells affected) to mirror what you'd encounter with genuine scraped or exported business data.

## Project Structure

```
├── raw_ecommerce_sales.csv          # Original, uncleaned dataset
├── cleaned_ecommerce_sales.csv      # Final cleaned dataset
├── ecommerce_sales_analysis.ipynb   # Full analysis notebook (cleaning + EDA + dashboard)
├── sales_dashboard.png              # Exported summary dashboard
└── README.md                        # This file
```

## Data Cleaning Steps

1. **Duplicates** — removed exact duplicate rows and duplicate `OrderID` entries
2. **Text standardization** — normalized inconsistent casing/spelling in `Category` and `CustomerCity` (e.g., `ELECTRONICS`/`electronics`, `Bangalore`/`Bengaluru`); converted blank/whitespace strings to proper missing values
3. **Date parsing** — parsed `OrderDate` from five mixed formats into a proper datetime column
4. **Outlier treatment** — fixed negative prices, capped extreme prices via the IQR method, flagged implausible ages and delivery times as missing
5. **Missing value imputation** — median imputation for numeric columns, explicit `"Unknown"` label for categorical columns
6. **Feature engineering** — derived `Revenue` (`Price × Quantity × (1 − Discount)`) and `OrderMonth` for trend analysis

See the notebook for the full reasoning behind each decision.

## Key Insights

- Revenue shows [seasonal peaks / notable spikes — fill in after reviewing the monthly trend chart]
- A small number of categories account for a disproportionate share of revenue
- Revenue is concentrated in a handful of top cities
- UPI and digital payment modes dominate over cash-on-delivery
- [Add your own observations on the rating vs. delivery-time relationship]

*(Edit this section with your own interpretation after reviewing the rendered charts — this is what turns a technical exercise into a portfolio piece.)*

## Tools & Libraries

- Python 3
- Pandas, NumPy — data manipulation
- Matplotlib, Seaborn — visualization
- Jupyter Notebook

## How to Run

```bash
pip install pandas numpy matplotlib seaborn jupyter
jupyter notebook ecommerce_sales_analysis.ipynb
```

Run all cells to reproduce the cleaning, EDA, and dashboard from the raw CSV.

## Author

Khushi — BE Computer Science and Business Systems, S G Balekundri Institute of Technology
